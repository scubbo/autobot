This repo initially set up by AutoBot, written by @scubbo
