def handler(event, context):
  return 5*event['val']
